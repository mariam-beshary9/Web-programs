/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
 //This assignment is made by student: Mariam Ahmed Amin
  // ID: 20170279
  // Group: CS IS G2
import databaseConnection.DatabaseConnection;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Mariam
 */
@WebServlet(urlPatterns = {"/deleteTransaction"})
public class deleteTransaction extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, SQLException, IOException, ClassNotFoundException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            int transID = Integer.parseInt(request.getParameter("transactionID"));
            DatabaseConnection dc = new DatabaseConnection();
            java.sql.Connection Con = dc.getConnection();
            java.sql.Statement stmt = Con.createStatement();
            //out.print(transID);
            ResultSet RS = stmt.executeQuery("SELECT * FROM banktransaction WHERE BankTransactionID=" + transID + ";");

            while (RS.next()) {

                long diff = new java.util.Date().getTime() - RS.getTimestamp(2).getTime();

                int diffDays = (int) (diff / (24 * 60 * 60 * 1000));

                if (diffDays > 1) {
                    out.println("<script>");
                    out.println("alert('You can not delete it, because it is longer than one day.');");
                    out.println("window.location.replace('transactions.jsp');");
                    out.println("</script>");
                    RS.close();
                    stmt.close();
                    Con.close();
                 
                } else {
                    java.sql.Statement stmt2 = Con.createStatement();
                    ResultSet RS2 = stmt2.executeQuery("SELECT * FROM bankaccount WHERE BankAccountID=" + RS.getInt(5) + ";");
                    
                    double toBalance = 0;
                    while (RS2.next()) {
                        toBalance += RS2.getDouble("BACurrentBalance");
                    }

                    RS2 = stmt2.executeQuery("SELECT * FROM bankaccount WHERE BankAccountID=" + RS.getInt(4) + ";");
                    
                    double balance = 0;
                    while (RS2.next()) {
                        balance += RS2.getDouble("BACurrentBalance");

                    }
                    stmt2.executeUpdate("UPDATE bankaccount SET BACurrentBalance=" + (toBalance - RS.getInt(3)) + " WHERE BankAccountID=" + RS.getInt(5) + ";");
                    stmt2.executeUpdate("UPDATE bankaccount SET BACurrentBalance=" + (balance + RS.getInt(3)) + " WHERE BankAccountID=" + RS.getInt(4) + ";");
                    stmt2.executeUpdate("DELETE FROM banktransaction WHERE BankTransactionID=" + transID + ";");
                    out.println("<script>");
                    out.println("alert('The Transaction in deleted.');");
                    out.println("window.location.replace('transactions.jsp');");
                    out.println("</script>");
                    RS.close();
                    RS2.close();
                    stmt.close();
                    stmt2.close();
                    Con.close();
                }
            }

        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(deleteTransaction.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(deleteTransaction.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(deleteTransaction.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(deleteTransaction.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
