/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
 //This assignment is made by student: Mariam Ahmed Amin
  // ID: 20170279
  // Group: CS IS G2
import databaseConnection.DatabaseConnection;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Marism
 */
@WebServlet(urlPatterns = {"/validate"})
public class validate extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {

            /* TODO output your page here. You may use following sample code. */
            String id = request.getParameter("ID");
            String password = request.getParameter("Password");
            DatabaseConnection dc = new DatabaseConnection();
            java.sql.Connection Con = dc.getConnection();
            java.sql.Statement stmt = Con.createStatement();
            try {
                ResultSet RS = stmt.executeQuery("SELECT COUNT(*) FROM customer WHERE CustomerID=" + id + " AND CustomerPassword='" + password + "' ;");
                int n = 0;
                while (RS.next()) {
                    n = RS.getInt(1);

                }
                if (n == 0) {
                    stmt.close();
                    Con.close();
                   
                    out.println("<script>");
                    out.println("alert('You have entered invalid data, login again.');");
                    out.println("window.location.replace('" + "Login.html" + "');");
                    out.println("</script>");
                } else {
                    stmt.close();
                    Con.close();
                   
                    HttpSession session = request.getSession(true);
                    session.setAttribute("ID", id);
                    response.sendRedirect("customerhome.jsp");

                }
                RS.close();
            } catch (SQLException e) {

                // response.sendRedirect("Login.html");
            }

            stmt.close();
            Con.close();
         
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(validate.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(validate.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
