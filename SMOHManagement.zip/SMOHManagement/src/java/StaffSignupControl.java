/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import DatabaseControl.User_DataAccess;
import Domain.User;
import Domain.User_Type;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.Properties;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import sun.rmi.transport.Transport;


/**
 *
 * @author maria
 */
@WebServlet(urlPatterns = {"/StaffSignupControl"})
public class StaffSignupControl extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException, ClassNotFoundException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            String username = request.getParameter("username");
            String name = request.getParameter("name");
            String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_";
            Random rand = new Random();
            int n = rand.nextInt(10);
            n += 5;

            String password = "";
            for (int i = 0; i < n; i++) {
                int n2 = rand.nextInt(characters.length() - 1);
                password += characters.charAt(n2);

            }
            String email = request.getParameter("email");
            String bio = request.getParameter("bio");

            //userType
            String regex = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";
            if (email.matches(regex)) {

                User_DataAccess smd = new User_DataAccess();

                User u = new User(name, password, username,
                        User_Type.Staff_Member, email, bio);
                if (smd.addUser(u)) {

                    out.println("<script>");
                    out.println("alert('The account is created successfully. Please check your email to get the password to log in.');");

                    String to = "sonoojaiswal1988@gmail.com";//change accordingly  
                    String from = "sonoojaiswal1987@gmail.com";

                    String host = "localhost";//or IP address  
                    
                    out.println("window.location.replace('LoginStaff.html');");
                    out.println("</script>");
                } else {

                    out.println("<script>");
                    out.println("alert('This username is not available.');");
                    out.println("window.location.replace('RegisterStaff.html');");
                    out.println("</script>");

                }
            } else {
                out.println("<script>");
                out.println("alert('This email is not valid.');");
                out.println("window.location.replace('RegisterStaff.html');");
                out.println("</script>");

            }

        }
    }

// <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);

        } catch (SQLException ex) {
            Logger.getLogger(StaffSignupControl.class
                    .getName()).log(Level.SEVERE, null, ex);

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(StaffSignupControl.class
                    .getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            processRequest(request, response);

        } catch (SQLException ex) {
            Logger.getLogger(StaffSignupControl.class
                    .getName()).log(Level.SEVERE, null, ex);

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(StaffSignupControl.class
                    .getName()).log(Level.SEVERE, null, ex);
        }

    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
