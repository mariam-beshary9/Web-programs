/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Domain;

import DatabaseControl.User_DataAccess;
import DatabaseControl.User_Subject_DataAccess;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author maria
 */
public class SearchAlgorithms {
    private User_DataAccess userDatabase;
    private User_Subject_DataAccess userSubjectDatabase;
    
    public SearchAlgorithms()
    {
        userDatabase = new User_DataAccess();
        userSubjectDatabase = new User_Subject_DataAccess();
    }
    
    
    public ArrayList<User> searchStaff( String query) throws SQLException {

        ArrayList<User> users = new ArrayList<User>();
        ArrayList<User> temp = userDatabase.getAllUsers();
        for (int g = 0; g < temp.size(); g++) {

            if ((temp.get(g).getUsername().contains(query)) || (temp.get(g).getName().contains(query))) {
                if(temp.get(g).getType().equals(User_Type.Staff_Member))
                        users.add(temp.get(g));
            }
        }

    Collections.sort (users, User.UserNameComparator);
    return users ;

}
        
    public ArrayList<User> searchStudents( String query) throws SQLException {

        ArrayList<User> users = new ArrayList<User>();
        ArrayList<User> temp = userDatabase.getAllUsers();
        for (int g = 0; g < temp.size(); g++) {

            if ((temp.get(g).getUsername().contains(query)) || (temp.get(g).getName().contains(query))) {
               if(temp.get(g).getType().equals(User_Type.Student))
                     users.add(temp.get(g));
            }
        }

    Collections.sort (users, User.UserNameComparator);
    return users ;

}
    
    public ArrayList<User> getStaffOfSubject(String subject) throws SQLException
    {
        ArrayList<String> usernames =  userSubjectDatabase.getUserofSubject( subject);
         ArrayList<User> users = new ArrayList<>();
         for(int i=0 ; i<usernames.size();i++)
         {
             User temp = userDatabase.getUserByUsername(usernames.get(i));
             if(temp.getType().equals(User_Type.Staff_Member))
                      users.add(temp);
         }
         return users;
    }
        public ArrayList<User> getStudentsOfSubject(String subject) throws SQLException
    {
        ArrayList<String> usernames =  userSubjectDatabase.getUserofSubject( subject);
         ArrayList<User> users = new ArrayList<>();
         for(int i=0 ; i<usernames.size();i++)
         {
             User temp = userDatabase.getUserByUsername(usernames.get(i));
             if(temp.getType().equals(User_Type.Student))
                      users.add(temp);
         }
         return users;
    }

public ArrayList<User> searchUserByUsername(String username) throws SQLException {
        ArrayList<User> users = new ArrayList();

        User user = userDatabase.getUserByUsername(username);
        users.add(user);
        return users;
    }

    
}
