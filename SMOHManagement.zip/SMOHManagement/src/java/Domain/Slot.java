/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Domain;

import java.sql.Date;
import java.time.LocalTime;
import java.util.Comparator;

/**
 *
 * @author maria
 */
public class Slot {

    private int slotID;
    private String studentUsername;
    private String staffUsername;
    private Date date;
    private String description;
    private LocalTime startTime;

    private LocalTime endTime;

    private String type;

    public Slot(int a, String su, String stu, Date d, String de, LocalTime st, LocalTime et, String t) {

        slotID = a;
        studentUsername = su;
        staffUsername = stu;
        date = d;
        description = de;
        startTime = st;
        endTime = et;
        type = t;

    }

    public void setStudentUsername(String su) {
        studentUsername = su;
    }

    public void setStaffUsername(String stu) {
        staffUsername = stu;
    }

    public void setDate(Date d) {
        date = d;
    }

    public void setDescription(String d) {
        description = d;
    }
    public void setStartTime(LocalTime t)
    {
        startTime=t;
    }
    public void setEndTime(LocalTime t)
    {
        endTime=t;
    }
    public void setType(String s)
    {
        type=s;
    }

    public String getStudentUsername() {
        return studentUsername;
    }

    public String getStaffUsername() {
        return staffUsername;
    }

    public Date getDate() {
        return date;
    }

    public int getSlotID() {
        return slotID;
    }

    public String getDescription() {
        return description;
    }

    public LocalTime getStartTime() {
        return startTime;
    }

    public LocalTime getEndTime() {
        return  endTime;
    }

    public String getType() {
        return type;
    }

    public static Comparator<Slot> AppointmentDateComparator = new Comparator<Slot>() {

        @Override
        public int compare(Slot a1, Slot a2) {

            return a1.getDate().compareTo(a2.getDate());

        }
    };
}
