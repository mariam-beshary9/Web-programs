/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Domain;

import java.util.Comparator;

/**
 *
 * @author maria
 */

public class User  {

    private String name;
    private String password;
    private String username;
    private User_Type type;
    private String email;
    private String bio;

    public User(String n, String p, String u,User_Type ut, String e, String b ) {
        name = n;
        password = p;
        username = u;
        type = ut;
        email = e;
        bio = b;
    }

    public void setName(String n) {
        name = n;

    }
    public void setUsername(String n) {
        username = n;

    }

    public void setPassword(String p) {
        password = p;

    }
    public void setEmail(String e) {
        email = e;

    }
    public void setBio(String b) {
        bio = b;

    }
    public String getName() {
        return name;
    }

    public String getPassword() {
        return password;
    }

    public String getUsername() {
        return username;
    }
    public String getEmail() {
        return email;

    }
    public String getBio() {
        return bio ;

    }
    public User_Type getType()
    {
        return type;
    }
    
    public static Comparator<User> UserNameComparator = new Comparator<User>() {

        @Override
	public int compare(User s1, User s2) {
	   String StudentName1 = s1.getName().toUpperCase();
	   String StudentName2 = s2.getName().toUpperCase();

	   //ascending order
	   return StudentName1.compareTo(StudentName2);

	   //descending order
	   //return StudentName2.compareTo(StudentName1);
    }};


}
