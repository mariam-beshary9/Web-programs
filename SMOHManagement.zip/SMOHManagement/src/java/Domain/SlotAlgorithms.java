/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Domain;

import DatabaseControl.Slot_DataAccess;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author maria
 */
public class SlotAlgorithms {
    protected Slot_DataAccess slotDatabase;
     
    public SlotAlgorithms(){
     slotDatabase = new Slot_DataAccess();
    }
    
    
    public ArrayList<ArrayList<Slot>> filterAppointments(ArrayList<Slot> slots) {
        ArrayList<Slot> historySlots = new ArrayList();
        ArrayList<Slot> currentSlots = new ArrayList();
        Date currentDate = new Date();
        for (int i = 0; i < slots.size(); i++) {
            if (slots.get(i).getDate().compareTo(currentDate) < 0) {

                historySlots.add(slots.get(i));
            } else {
                currentSlots.add(slots.get(i));
            }
        }
        ArrayList<ArrayList<Slot>> slots_types = new ArrayList();
        slots_types.add(historySlots);
      
        slots_types.add(currentSlots);
        return slots_types;
    }
    
    public ArrayList<ArrayList<Slot>> viewSlots(String username) throws SQLException {
        ArrayList<Slot> slots = slotDatabase.getSlotsStaff(username);
        
        return filterAppointments(slots);
    }
        public ArrayList<ArrayList<Slot>> viewAppointments(String username) throws SQLException {
        ArrayList<Slot> slots = slotDatabase.getAppoinmentsStudent(username);
        
        return filterAppointments(slots);
    }
            public boolean cancelAllAppointmentsOnDate(Date date) throws SQLException {
        if (slotDatabase.deleteAppointmentsByDate((java.sql.Date) date)) {
            return true;
        } else {
            return false;
        }
    }
}
