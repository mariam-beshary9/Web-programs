/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DatabaseControl;

import Domain.User;
import Domain.User_Type;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.servlet.http.HttpSession;

/**
 *
 * @author maria
 */
public class User_DataAccess {


    public User_DataAccess() {
      
    }

    // add a user
    public boolean addUser(User user) throws SQLException {
        Database_Connection dc = new Database_Connection();
        java.sql.Connection connection = dc.getConnection();
        java.sql.Statement statement = connection.createStatement();

        try {
            statement.executeUpdate("INSERT INTO user VALUES('" + user.getUsername() + "', '" + user.getName() + "','" + user.getPassword() + "','" + user.getType().toString() + "','" + user.getEmail() + "', '" + user.getBio() + "');");
            
            statement.close();
            connection.close();
             dc.closeConnection();
            return true;
        } catch (SQLException e) {
            statement.close();
            connection.close();
             dc.closeConnection();
            return false;
        }

    }

    // get specific user
    public User getUserByUsername(String username) throws SQLException {
        Database_Connection dc = new Database_Connection();
        java.sql.Connection connection = dc.getConnection();
        java.sql.Statement statement = connection.createStatement();
        User myUser = null;
        try {

            ResultSet RS = statement.executeQuery("SELECT * FROM user WHERE username= '" + username + "' ;");
            while (RS.next()) {
                myUser = new User(RS.getString(2), RS.getString(3), username, User_Type.valueOf(RS.getString(4)), RS.getString(5), RS.getString(6));
            }
            RS.close();

        } catch (SQLException e) {

        }
        statement.close();
        connection.close();
         dc.closeConnection();
        return myUser;

    }
    public ArrayList<User> getUserByName(String name) throws SQLException {
        Database_Connection dc = new Database_Connection();
        java.sql.Connection connection = dc.getConnection();
        java.sql.Statement statement = connection.createStatement();
        ArrayList<User> myUsers = null;
        try {

            ResultSet RS = statement.executeQuery("SELECT * FROM user WHERE CONTAINS(name,'"+name + "') ;");
            while (RS.next()) {
                myUsers.add(new User(RS.getString(2), RS.getString(3), RS.getString(1), User_Type.valueOf(RS.getString(4)), RS.getString(5), RS.getString(6)));
            }
            RS.close();

        } catch (SQLException e) {

        }
        statement.close();
        connection.close();
         dc.closeConnection();
        return myUsers;

    }
    public ArrayList<User> getAllUsers() throws SQLException
    {
        Database_Connection dc = new Database_Connection();
        java.sql.Connection connection = dc.getConnection();
        java.sql.Statement statement = connection.createStatement();
        ArrayList<User> myUsers = new ArrayList<>() ;
        
        try {

            ResultSet RS = statement.executeQuery("SELECT * FROM user ;");
            while (RS.next()) {
                
                myUsers.add(new User(RS.getString(2), RS.getString(3), RS.getString(1), User_Type.valueOf(RS.getString(4)), RS.getString(5), RS.getString(6)));
            }
            RS.close();

        } catch (SQLException e) {

        }
        statement.close();
        connection.close();
         dc.closeConnection();
        return myUsers;
    }
 public ArrayList<User> getAllStaffUsers() throws SQLException
    {
        Database_Connection dc = new Database_Connection();
        java.sql.Connection connection = dc.getConnection();
        java.sql.Statement statement = connection.createStatement();
        ArrayList<User> myUsers = new ArrayList<>() ;
        
        try {

            ResultSet RS = statement.executeQuery("SELECT * FROM user WHERE type="+User_Type.Staff_Member+";");
            while (RS.next()) {
                
                myUsers.add(new User(RS.getString(2), RS.getString(3), RS.getString(1), User_Type.valueOf(RS.getString(4)), RS.getString(5), RS.getString(6)));
            }
            RS.close();

        } catch (SQLException e) {

        }
        statement.close();
        connection.close();
        return myUsers;
    }

    
    // modify specific user
    public boolean updateUser(User user) throws SQLException {
        
        Database_Connection dc = new Database_Connection();
        java.sql.Connection connection = dc.getConnection();
        java.sql.Statement statement = connection.createStatement();

        try {
            PreparedStatement update = connection.prepareStatement("UPDATE user SET name = ?, password = ?, email = ?, bio = ? WHERE username = ? ;");

            update.setString(1, user.getName());
            update.setString(2, user.getPassword());
            update.setString(3, user.getEmail());
            update.setString(4, user.getBio());
            update.setString(5, user.getUsername());

            int i=update.executeUpdate();

            statement.close();
            connection.close();
            dc.closeConnection();
            if(i==0){
                return false;
            }
            return true;
        } catch (SQLException e) {
            statement.close();
            connection.close();
             dc.closeConnection();
            return false;
        }

    }

    // delete specific user
}
