/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DatabaseControl;

import Domain.Slot;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalTime;
import java.util.ArrayList;

/**
 *
 * @author maria
 */
public class Slot_DataAccess {


    public Slot_DataAccess() {
        
    }

    // add a user
    public boolean addSlot(String staffUsername,
            Date date, String descr, LocalTime st , LocalTime et , String type) throws SQLException {
        
         Database_Connection dc = new Database_Connection();
        java.sql.Connection connection = dc.getConnection();
        java.sql.Statement statement = connection.createStatement();

        int n = 0;
        ResultSet rs = statement.executeQuery("SELECT MAX(slotID) FROM slot");
        while (rs.next()) {
            n = rs.getInt(1);
        }
        n+=1;
        try {
            statement.executeUpdate("INSERT INTO slot VALUES(" + n + ", 'No-student','" + staffUsername + "','" + date + "','" + descr + "','"+st+"','"+et+"','"+type+"');");
            statement.close();
            connection.close();
            dc.closeConnection();
            return true;
            
        } catch (SQLException e) {
            statement.close();
            connection.close();
            dc.closeConnection();
            
            return false;
        }

    }
    
    public boolean checkStaffHaveSlots(String username) throws SQLException {
        Database_Connection dc = new Database_Connection();
        java.sql.Connection connection = dc.getConnection();
        java.sql.Statement statement = connection.createStatement();
        int k = 0;
        try {
            ResultSet RS = statement.executeQuery("SELECT COUNT(*) FROM slot WHERE staffUsername= '" + username + "' ;");
            while (RS.next()) {
                k = RS.getInt(1);
            }
            RS.close();

        } catch (SQLException e) {

        }
        statement.close();
        connection.close();
        dc.closeConnection();
        if (k > 0) {
            return true;
        } else {
            return false;
        }
    }
     public boolean checkStudentHaveSlots(String username) throws SQLException {
         Database_Connection dc = new Database_Connection();
        java.sql.Connection connection = dc.getConnection();
        java.sql.Statement statement = connection.createStatement();
        int k = 0;
        try {
            ResultSet RS = statement.executeQuery("SELECT COUNT(*) FROM slot WHERE studentUsername= '" + username + "' ;");
            while (RS.next()) {
                k = RS.getInt(1);
            }
            RS.close();

        } catch (SQLException e) {

        }
        statement.close();
        connection.close();
        dc.closeConnection();
        if (k > 0) {
            return true;
        } else {
            return false;
        }
    }
         public Slot getSlotByID(int id) throws SQLException {
        Database_Connection dc = new Database_Connection();
        java.sql.Connection connection = dc.getConnection();
        java.sql.Statement statement = connection.createStatement();
       Slot s = null;
        try {
            ResultSet RS = statement.executeQuery("SELECT * FROM slot WHERE slotID= '" + id + "' ;");
            while (RS.next()) {
                 String temp = RS.getString(6);
                LocalTime st = LocalTime.parse(temp);
                temp = RS.getString(7);
                LocalTime et = LocalTime.parse(temp);
                s =new Slot(RS.getInt(1), RS.getString(2), RS.getString(3), RS.getDate(4), RS.getString(5),st,et,RS.getString(8));
            }
            RS.close();

        } catch (SQLException e) {

        }
        statement.close();
        connection.close();
        dc.closeConnection();
        return s;
    }

    // get specific user
    public ArrayList<Slot> getAppoinmentsStudent(String username) throws SQLException {
        Database_Connection dc = new Database_Connection();
        java.sql.Connection connection = dc.getConnection();
        java.sql.Statement statement = connection.createStatement();
        ArrayList<Slot> appointments = new ArrayList<>();
        try {
            ResultSet RS = statement.executeQuery("SELECT * FROM slot WHERE studentUsername= '" + username + "' ;");
            while (RS.next()) {
                 String temp = RS.getString(6);
                LocalTime st = LocalTime.parse(temp);
                temp = RS.getString(7);
                LocalTime et = LocalTime.parse(temp);
                appointments.add(new Slot(RS.getInt(1), RS.getString(2), RS.getString(3), RS.getDate(4), RS.getString(5),st,et,RS.getString(8)));
            }
            RS.close();

        } catch (SQLException e) {

        }
        statement.close();
        connection.close();
        dc.closeConnection();
        return appointments;
    }

    public ArrayList<Slot> getSlotsStaff(String username) throws SQLException {
        
        Database_Connection dc = new Database_Connection();
        java.sql.Connection connection = dc.getConnection();
        java.sql.Statement statement = connection.createStatement();
        ArrayList<Slot> appointments = new ArrayList<>();
        try {
            ResultSet RS = statement.executeQuery("SELECT * FROM slot WHERE staffUsername= '" + username + "' ;");
            while (RS.next()) {
                String temp = RS.getString(6);
                LocalTime st = LocalTime.parse(temp);
                temp = RS.getString(7);
                LocalTime et = LocalTime.parse(temp);
                appointments.add(new Slot(RS.getInt(1), RS.getString(2), RS.getString(3), RS.getDate(4), RS.getString(5),st,et,RS.getString(8)));
            }
            RS.close();

        } catch (SQLException e) {

        }
        statement.close();
        connection.close();
        dc.closeConnection();
        return appointments;
    }


    public boolean deleteAppoinmentByID(int id) throws SQLException {
        Database_Connection dc = new Database_Connection();
        java.sql.Connection connection = dc.getConnection();
        java.sql.Statement statement = connection.createStatement();
        try {
            statement.executeUpdate("DELETE FROM slot WHERE slotID=" + id + ";");
            statement.close();
            connection.close();
            dc.closeConnection();
            return true;

        } catch (SQLException e) {
            statement.close();
            connection.close();
            dc.closeConnection();
            return false;
        }
    }

    public boolean deleteAppointmentsByDate(Date date) throws SQLException {
        Database_Connection dc = new Database_Connection();
        java.sql.Connection connection = dc.getConnection();
        java.sql.Statement statement = connection.createStatement();
        try {
            statement.executeUpdate("DELETE FROM slot WHERE date='" + date + "';");
            statement.close();
            connection.close();
            dc.closeConnection();
            return true;

        } catch (SQLException e) {
            statement.close();
            connection.close();
            dc.closeConnection();
            return false;
        }
    }

    public boolean updateSlotDate(int id,
            Date date) throws SQLException {
        Database_Connection dc = new Database_Connection();
        java.sql.Connection connection = dc.getConnection();
        java.sql.Statement statement = connection.createStatement();

        try {
            statement.executeUpdate("UPDATE slot SET date='" + date + "' WHERE slotID='" + id + "');");
            statement.close();
            connection.close();
            dc.closeConnection();
            return true;
        } catch (SQLException e) {
            statement.close();
            connection.close();
            dc.closeConnection();
            return false;
        }

    }

    public boolean updateSlotDescription(int id, String descr) throws SQLException {
        Database_Connection dc = new Database_Connection();
        java.sql.Connection connection = dc.getConnection();
        java.sql.Statement statement = connection.createStatement();

        try {
            statement.executeUpdate("UPDATE slot SET description='" + descr + "' WHERE slotID='" + id + "');");
            statement.close();
            connection.close();
            dc.closeConnection();
            return true;
        } catch (SQLException e) {
            statement.close();
            connection.close();
            dc.closeConnection();
            return false;
        }

    }

    public boolean updateSlotStudent(int id, String studentUsername) throws SQLException {
        Database_Connection dc = new Database_Connection();
        java.sql.Connection connection = dc.getConnection();
        java.sql.Statement statement = connection.createStatement();

        try {
            statement.executeUpdate("UPDATE slot SET studentUsername = '" + studentUsername + "' WHERE slotID=" + id + ";");
            statement.close();
            connection.close();
            dc.closeConnection();
            return true;
        } catch (SQLException e) {
            statement.close();
            connection.close();
            dc.closeConnection();
            return false;
        }

    }
    public ArrayList<Date> getDays (String staffUsername) throws SQLException
    {
        Database_Connection dc = new Database_Connection();
        java.sql.Connection connection = dc.getConnection();
        java.sql.Statement statement = connection.createStatement();
        ArrayList<Date> dates = new ArrayList<>();
        try {
            ResultSet RS = statement.executeQuery("SELECT DISTINCT(date) FROM slot WHERE staffUsername='"+staffUsername+"';");
            while (RS.next()) {
                
                dates.add(RS.getDate(1));
            }
            RS.close();

        } catch (SQLException e) {

        }
        statement.close();
        connection.close();
        dc.closeConnection();
        return dates;
    }
        public boolean updateSlot(Slot s) throws SQLException {
        Database_Connection dc = new Database_Connection();
        java.sql.Connection connection = dc.getConnection();
        java.sql.Statement statement = connection.createStatement();

        try {
            statement.executeUpdate("UPDATE slot SET date = '" + s.getDate()+ "', description='"+s.getDescription()+"',startTime='"+s.getStartTime()+"',endTime='"+s.getEndTime()+"',type='"+s.getType()+"'  WHERE slotID=" + s.getSlotID() + ";");
            statement.close();
            connection.close();
            dc.closeConnection();
            return true;
        } catch (SQLException e) {
            statement.close();
            connection.close();
            dc.closeConnection();
            return false;
        }

    }

}
