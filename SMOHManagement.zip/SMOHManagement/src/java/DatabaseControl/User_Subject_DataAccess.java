/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DatabaseControl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author maria
 */
public class User_Subject_DataAccess {

    public User_Subject_DataAccess() {
      
    }

    // add a user
    public boolean addUserSubject(String username, String subject) throws SQLException {
        Database_Connection dc = new Database_Connection();
        java.sql.Connection connection = dc.getConnection();
        java.sql.Statement statement = connection.createStatement();

        try {
            statement.executeUpdate("INSERT INTO user_subject VALUES('" + username + "', '" + subject + "');");
            statement.close();
            connection.close();
            return true;
        } catch (SQLException e) {
            statement.close();
            connection.close();
            return false;
        }

    }

    public ArrayList<String> getSubjects(String username) throws SQLException {
        Database_Connection dc = new Database_Connection();
        java.sql.Connection connection = dc.getConnection();
        java.sql.Statement statement = connection.createStatement();
        ArrayList<String> subjects = new ArrayList();
        try {
            ResultSet RS = statement.executeQuery("SELECT username FROM user_subject WHERE username= '" + username + "' ;");;
            while (RS.next()) {
                subjects.add(RS.getString(1));
            }
            RS.close();

        } catch (SQLException e) {

        }
        statement.close();
        connection.close();
        return subjects;

    }

    public ArrayList<String> getUserofSubject(String subject) throws SQLException {
        Database_Connection dc = new Database_Connection();
        java.sql.Connection connection = dc.getConnection();
        java.sql.Statement statement = connection.createStatement();
        ArrayList<String> usernames = new ArrayList();
        try {
            ResultSet RS = statement.executeQuery("SELECT username FROM user_subject WHERE subjectName= '" + subject + "' ;");;
            while (RS.next()) {
                usernames.add(RS.getString(1));
            }
            RS.close();

        } catch (SQLException e) {

        }
        statement.close();
        connection.close();
        return usernames;

    }

    public ArrayList<String> getAllSubjects() throws SQLException {
        ArrayList<String> subjects = new ArrayList<>();
        Database_Connection dc = new Database_Connection();
        java.sql.Connection connection = dc.getConnection();
        java.sql.Statement statement = connection.createStatement();

        try {
            ResultSet RS = statement.executeQuery("SELECT DISTINCT subjectName FROM user_subject ;");;
            while (RS.next()) {
                subjects.add(RS.getString(1));
            }
            RS.close();

        } catch (SQLException e) {

        }
        statement.close();
        connection.close();

        return subjects;

    }
}
