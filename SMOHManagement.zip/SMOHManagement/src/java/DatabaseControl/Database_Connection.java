/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DatabaseControl;

import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author maria
 */
public class Database_Connection {
    
    private static java.sql.Connection con = null; 
    
     public Database_Connection() 
    { 
           
           try { 
            Class.forName("com.mysql.jdbc.Driver"); 
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/staff_management", "root", "myPassword"); 
        } 
        catch (ClassNotFoundException | SQLException e) { 
            e.printStackTrace(); 
        } 
    } 
    public static java.sql.Connection getConnection() 
    { 
        return con; 
    } 
    public void closeConnection() throws SQLException
    {
        con.close();
    }
}
