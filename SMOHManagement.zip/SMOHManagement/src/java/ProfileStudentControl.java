/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import DatabaseControl.User_DataAccess;
import Domain.User;
import Domain.User_Type;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author maria
 */
@WebServlet(urlPatterns = {"/ProfileStudentControl"})
public class ProfileStudentControl extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
       protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            String name = request.getParameter("nameS");
            //out.print(name);
            String password = request.getParameter("passwordS");
            String email = request.getParameter("emailS");
            String bio = request.getParameter("bioS");
            
            HttpSession session = request.getSession();
            User user = (User) session.getAttribute("me");
           // out.print(user.getType()+user.getUsername());

            if ( name!=null && !name.isEmpty()) {
                user.setName(name);
            }

            if (password!=null && !password.isEmpty()) {
                user.setPassword(password);

            }
            if (email!=null && !email.isEmpty()) {
                String regex = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";
                if (email.matches(regex)) {
                    user.setEmail(email);

                } else {

                    out.println("<script>");
                    out.println("alert('Your email is not valid.');");
                    out.println("window.location.replace('ProfileStudent.html');");
                    out.println("</script>");
                }
            }

            if (bio!=null && !bio.isEmpty()) {

                user.setBio(bio);

            }
            User_DataAccess ud = new User_DataAccess();
            
            
            if (ud.updateUser(user)) {
                out.print(user.getName());
         
                session.setAttribute("me", user);
                
                out.println("<script>");
                out.println("alert('Your profile is updated.');");
                out.println("window.location.replace('ProfileStudent.html');");
                out.println("</script>");

            } else {
                out.println("<script>");
                out.println("alert('Could not update the profile.');");
                out.println("window.location.replace('ProfileStudent.html');");
                out.println("</script>");
            }
        }}

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
           try {
               processRequest(request, response);
           } catch (SQLException ex) {
               Logger.getLogger(ProfileStudentControl.class.getName()).log(Level.SEVERE, null, ex);
           }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
           try {
               processRequest(request, response);
           } catch (SQLException ex) {
               Logger.getLogger(ProfileStudentControl.class.getName()).log(Level.SEVERE, null, ex);
           }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
